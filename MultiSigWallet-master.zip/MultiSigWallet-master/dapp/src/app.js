(
  function () {
    angular.module(
      'multiSigWeb',
      [
        'ui.bootstrap',
        'ngRoute',
        'ngclipboard',
        'ui-notification'     
      ]
    );
  }
)();
