// Spell
console.log("spell.js loaded!");

function Spell(name){
  this.name = name;
  this.damage = 0;
  this.affect = 0;
  this.manaCost = 0;
}
