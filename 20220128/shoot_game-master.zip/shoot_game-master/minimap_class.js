class MinimapClass {
  constructor() {}

  drawMinimap(drawingContext) {}
}
