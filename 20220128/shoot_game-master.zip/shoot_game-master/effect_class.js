class EffectClass {
  constructor(screenWidth, screenHeight) {
    this.screenWidth = screenWidth;
    this.screenHeight = screenHeight;
  }

  drawEffects(drawingContext, cameraClass) {
    
  }
}