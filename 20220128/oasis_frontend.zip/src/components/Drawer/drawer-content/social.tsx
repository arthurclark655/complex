import { Link } from "@material-ui/core";

export default function Social() {
    return (
        <div className="social-row">
            <Link href="https://github.com/Wonderland-Money/wonderland-frontend" target="_blank">
                <span className="iconify" data-icon="mdi:github"></span>
            </Link>

            <Link href="https://twitter.com/wonderland_fi?s=21" target="_blank">
                <span className="iconify" data-icon="akar-icons:twitter-fill"></span>
            </Link>

            <Link href="https://t.me/joinchat/6UybL5rJMEhjN2Y5" target="_blank">
                <span className="iconify" data-icon="la:telegram"></span>
            </Link>

            <Link href="https://discord.gg/thDHseaHUt" target="_blank">
                <span className="iconify" data-icon="ph:discord-logo"></span>
            </Link>
        </div>
    );
}
