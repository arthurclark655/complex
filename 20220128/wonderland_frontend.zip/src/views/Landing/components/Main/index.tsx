import React from "react";
import { Link } from "@material-ui/core";
import "./main.scss";
import OasisImg from "../../../../assets/icons/OasisLogo.png";

function Main() {
    return (
        <div className="landing-main">
            <div className="landing-main-img-wrap">
                <img src={OasisImg} alt="" />
            </div>
            <div className="landing-main-btns-wrap">
                {/* <Link href="/dashboard" target="_blank" rel="noreferrer"> */}
                <Link href="https://app.santadoge.xyz/" target="_blank" rel="noreferrer">
                    <div className="landing-main-btn">
                        <p>Enter App</p>
                    </div>
                </Link>
                <Link href="#" target="_blank" rel="noreferrer">
                    <div className="landing-main-btn">
                        <p>Documentation</p>
                    </div>
                </Link>
            </div>
            <div className="landing-main-title-wrap">
                <p style={{fontSize: 30}}>The DeFi</p>
                <p>O A S I S</p>
            </div>
            <div className="landing-main-help-text-wrap">
                <p>Financial tools to grow your wealth - stake</p>
                <p>and earn compounding interest</p>
            </div>
        </div>
    );
}

export default Main;
