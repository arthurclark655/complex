// import { Networks } from "../../constants/blockchain";
// import { LPBond, CustomLPBond } from "./lp-bond";
// import { StableBond, CustomBond } from "./stable-bond";

// import MimIcon from "../../assets/tokens/MIM.svg";
// import AvaxIcon from "../../assets/tokens/AVAX.svg";
// import MimTimeIcon from "../../assets/tokens/TIME-MIM.svg";
// import AvaxTimeIcon from "../../assets/tokens/TIME-AVAX.svg";

// import { StableBondContract, LpBondContract, WavaxBondContract, StableReserveContract, LpReserveContract } from "../../abi";

// export const mim = new StableBond({
//     name: "mim",
//     displayName: "MIM",
//     bondToken: "MIM",
//     bondIconSvg: MimIcon,
//     bondContractABI: StableBondContract,
//     reserveContractAbi: StableReserveContract,
//     networkAddrs: {
//         [Networks.AVAX]: {
//             bondAddress: "0x694738E0A438d90487b4a549b201142c1a97B556",
//             reserveAddress: "0x130966628846BFd36ff31a822705796e8cb8C18D",
//         },
//     },
// });

// export const wavax = new CustomBond({
//     name: "wavax",
//     displayName: "wAVAX",
//     bondToken: "AVAX",
//     bondIconSvg: AvaxIcon,
//     bondContractABI: WavaxBondContract,
//     reserveContractAbi: StableReserveContract,
//     networkAddrs: {
//         [Networks.AVAX]: {
//             bondAddress: "0xE02B1AA2c4BE73093BE79d763fdFFC0E3cf67318",
//             reserveAddress: "0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7",
//         },
//     },
// });

// export const mimTime = new LPBond({
//     name: "mim_time_lp",
//     displayName: "TIME-MIM LP",
//     bondToken: "MIM",
//     bondIconSvg: MimTimeIcon,
//     bondContractABI: LpBondContract,
//     reserveContractAbi: LpReserveContract,
//     networkAddrs: {
//         [Networks.AVAX]: {
//             bondAddress: "0xA184AE1A71EcAD20E822cB965b99c287590c4FFe",
//             reserveAddress: "0x113f413371fc4cc4c9d6416cf1de9dfd7bf747df",
//         },
//     },
//     lpUrl: "https://www.traderjoexyz.com/#/pool/0x130966628846BFd36ff31a822705796e8cb8C18D/0xb54f16fB19478766A268F172C9480f8da1a7c9C3",
// });

// export const avaxTime = new CustomLPBond({
//     name: "avax_time_lp",
//     displayName: "TIME-AVAX LP",
//     bondToken: "AVAX",
//     bondIconSvg: AvaxTimeIcon,
//     bondContractABI: LpBondContract,
//     reserveContractAbi: LpReserveContract,
//     networkAddrs: {
//         [Networks.AVAX]: {
//             bondAddress: "0xc26850686ce755FFb8690EA156E5A6cf03DcBDE1",
//             reserveAddress: "0xf64e1c5B6E17031f5504481Ac8145F4c3eab4917",
//         },
//     },
//     lpUrl: "https://www.traderjoexyz.com/#/pool/AVAX/0xb54f16fB19478766A268F172C9480f8da1a7c9C3",
// });

// export default [mim, wavax, mimTime, avaxTime];


import { Networks } from "../../constants/blockchain";
import { LPBond, CustomLPBond } from "./lp-bond";
import { StableBond, CustomBond } from "./stable-bond";

import MimIcon from "../../assets/tokens/MIM.png";
import AvaxIcon from "../../assets/tokens/AVAX.png";
import MimTimeIcon from "../../assets/tokens/TIME-MIM.png";
import AvaxTimeIcon from "../../assets/tokens/TIME-AVAX.png";

import { StableBondContract, LpBondContract, WavaxBondContract, StableReserveContract, LpReserveContract } from "../../abi";

export const mim = new StableBond({
    name: "mim",
    displayName: "BUSD",
    bondToken: "MIM",
    bondIconSvg: MimIcon,
    bondContractABI: StableBondContract,
    reserveContractAbi: StableReserveContract,
    networkAddrs: {
        [Networks.TESTBSC]: {
            bondAddress: "0x0fd0Fda1De617217B95dAD825F909bd5c2155c60",
            reserveAddress: "0x78867BbEeF44f2326bF8DDd1941a4439382EF2A7", // BUSD token
        },
    },
});

export const wavax = new CustomBond({
    name: "wavax",
    displayName: "WBNB",
    bondToken: "AVAX",
    bondIconSvg: AvaxIcon,
    bondContractABI: WavaxBondContract,
    reserveContractAbi: StableReserveContract,
    networkAddrs: {
        [Networks.TESTBSC]: {
            bondAddress: "0x83a3934dFFf828f007383E3A1eb8baEF3efE0C55",
            reserveAddress: "0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd", // WBNB token
        },
    },
});

export const mimTime = new LPBond({
    name: "mim_time_lp",
    displayName: "OAS-BUSD LP",
    bondToken: "MIM",
    bondIconSvg: MimTimeIcon,
    bondContractABI: LpBondContract,
    reserveContractAbi: LpReserveContract,
    networkAddrs: {
        [Networks.TESTBSC]: {
            bondAddress: "0xdCa9Ebc6486AA1c70A001Be70655b3133CAEf72E", //TimeBondDepository
            reserveAddress: "0x285d4F2Fee6d642d1Cc3E2BC9954F2DA922Ef3A6", //LP(OAS-BUSD)
        },
    },
    lpUrl: "https://pancakeswap.finance/add/0x78867BbEeF44f2326bF8DDd1941a4439382EF2A7/0xAb0A42d2C8B94698912dD0F0f510168068B53c0C", //MIM/TIME
});

export const avaxTime = new CustomLPBond({
    name: "avax_time_lp",
    displayName: "OAS-WBNB LP",
    bondToken: "AVAX",
    bondIconSvg: AvaxTimeIcon,
    bondContractABI: LpBondContract,
    reserveContractAbi: LpReserveContract,
    networkAddrs: {
        [Networks.TESTBSC]: {
            bondAddress: "0xBEAD0EbA597a99f19787CDB26aEee17BAea5ab00",
            reserveAddress: "0x7DB53fDfa91F01e5063fF124d127B14577B40a46", // LP OAS-BNB
        },
    },
    lpUrl: "https://pancakeswap.finance/add/BNB/0xAb0A42d2C8B94698912dD0F0f510168068B53c0C",
});

// export default [mim, wavax, mimTime, avaxTime];
export default [mim, mimTime, avaxTime];

