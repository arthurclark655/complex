import { Link } from "@material-ui/core";

export default function Social() {
    return (
        <div className="social-row">
            <Link href="#" target="_blank">
                <span className="iconify" data-icon="mdi:github"></span>
            </Link>

            <Link href="#" target="_blank">
                <span className="iconify" data-icon="akar-icons:twitter-fill"></span>
            </Link>

            <Link href="#" target="_blank">
                <span className="iconify" data-icon="la:telegram"></span>
            </Link>

            <Link href="#" target="_blank">
                <span className="iconify" data-icon="ph:discord-logo"></span>
            </Link>
        </div>
    );
}
