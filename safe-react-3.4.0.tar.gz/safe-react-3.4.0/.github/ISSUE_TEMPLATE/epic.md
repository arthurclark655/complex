---
name: Epic
about: Create an epic for the Gnosis Safe

---

# What is this feature about? (1 sentence)


# Why is it needed? What is the value? For whom do we build it?


# High-level overview of the feature
- 

# Screens
- Link to Google docs with screens. Template can be found on [Google drive](https://drive.google.com/drive/u/0/folders/1d7LH762wUBCSf2Shmb-f2O5OdAaQcOAW)

# Other things
- 
