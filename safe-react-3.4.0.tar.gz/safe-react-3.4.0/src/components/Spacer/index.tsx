import * as React from 'react'

const style = {
  flexGrow: 1,
}

// eslint-disable-next-line react/display-name
export default ({ className }: any) => <div className={className} style={style} />
