import React from 'react'
import { Field } from 'react-final-form'

// $FlowFixMe
const GnoField = ({ ...props }: any) => <Field {...props} />

export default GnoField
