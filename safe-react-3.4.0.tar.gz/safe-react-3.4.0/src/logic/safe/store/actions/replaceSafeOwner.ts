import { createAction } from 'redux-actions'

export const REPLACE_SAFE_OWNER = 'REPLACE_SAFE_OWNER'

export const replaceSafeOwner = createAction(REPLACE_SAFE_OWNER)
