import { createAction } from 'redux-actions'

export const UPDATE_SAFE = 'UPDATE_SAFE'

const updateSafe = createAction(UPDATE_SAFE)

export default updateSafe
