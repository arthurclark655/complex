import { createAction } from 'redux-actions'

export const ADD_SAFE_OWNER = 'ADD_SAFE_OWNER'

export const addSafeOwner = createAction(ADD_SAFE_OWNER)
