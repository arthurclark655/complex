export const COOKIES_KEY = 'COOKIES'
