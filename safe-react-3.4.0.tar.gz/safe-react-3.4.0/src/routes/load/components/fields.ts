export const FIELD_LOAD_NAME = 'name'
export const FIELD_LOAD_ADDRESS = 'address'
export const THRESHOLD = 'threshold'
