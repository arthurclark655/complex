const fs = require("fs");

const ChipToken = artifacts.require("ChipToken");
const FishToken = artifacts.require("FishToken");
const MpeaToken = artifacts.require("MpeaToken");
const ChipRewardPool = artifacts.require("ChipRewardPool");
const FishRewardPool = artifacts.require("FishRewardPool");
const Boardroom = artifacts.require("Boardroom");
const ChipSwapMechanism = artifacts.require("ChipSwapMechanism");
const Oracle = artifacts.require("Oracle");
const Treasury = artifacts.require("Treasury");
const TreasuryTest = artifacts.require("TreasuryTest");

const startBlockNumber = 30000000;

function writeLog(value) {
  fs.appendFile("/log/address.txt", value, function(err) {
    if (err) {
      return console.log(err);
    }
    console.log("The file was saved!");
  });
}

module.exports = function(deployer) {
  deployer.deploy(TreasuryTest);
  // deployer.deploy(ChipToken).then(() => {
  //   writeLog(`ChipToken Address: ${ ChipToken.address }`);
  //   deployer.deploy(ChipRewardPool, ChipToken.address, startBlockNumber).then(() => {
  //     writeLog(`ChipRewardPool Address: ${ ChipRewardPool.address }`);
  //   });
  //   deployer.deploy(FishToken).then(() => {
  //     writeLog(`FishToken Address: ${ FishToken.address }`);
  //     deployer.deploy(FishRewardPool, FishToken.address, startBlockNumber).then(() => {
  //       writeLog(`FishRewardPool Address: ${ FishRewardPool.address }`);
  //     });
  //     deployer.deploy(ChipSwapMechanism, ChipToken.address, FishToken.address).then(() => {
  //       writeLog(`ChipSwapMechanism Address: ${ ChipSwapMechanism.address }`);
  //     });
  //   });
  // });

  // deployer.deploy(Boardroom).then(() => {
  //   writeLog(`Boardroom Address: ${ Boardroom.address }`);
  // });
  // deployer.deploy(Oracle).then(() => {
  //   writeLog(`Oracle Address: ${ Oracle.address }`);
  // });
  // deployer.deploy(Treasury).then(() => {
  //   writeLog(`Treasury Address: ${ Treasury.address }`);
  // });
  // deployer.deploy(MpeaToken).then(() => {
  //   writeLog(`MpeaToken Address: ${ MpeaToken.address }`);
  // });
};
