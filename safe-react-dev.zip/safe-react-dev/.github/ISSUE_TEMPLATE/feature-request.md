---
name: Feature request
about: Create a feature request for the Gnosis Safe

---

## Overview

## Goals

## Requirements

## Screens
 - Figma:
 - Zeplin:

## Links
