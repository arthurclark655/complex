export const FIELD_LOAD_CUSTOM_SAFE_NAME = 'customSafeName'
export const FIELD_LOAD_SAFE_NAME = 'safeName'
export const FIELD_LOAD_ADDRESS = 'address'
export const THRESHOLD = 'threshold'
