import removeSnackbar from 'src/logic/notifications/store/actions/removeSnackbar'

export default {
  removeSnackbar,
}
